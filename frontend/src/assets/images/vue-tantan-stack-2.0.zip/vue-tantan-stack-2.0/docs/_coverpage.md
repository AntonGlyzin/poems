# vue-concise-slider

> A simple vue sliding component

- Simple and lightweight (~23kB gzipped)
- Multiple sliding effects
- Simple configuration


[GitHub](https://github.com/warpcgd/vue-concise-slider)
[Get Started](#vue-concise-slider)