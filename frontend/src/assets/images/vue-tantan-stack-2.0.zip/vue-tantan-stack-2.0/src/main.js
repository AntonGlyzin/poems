// 基础滚动
import stack from './demo/stack_basic'
// 实例vue
new Vue(stack)