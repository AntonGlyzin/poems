import stack from './components/stack'
export default stack
